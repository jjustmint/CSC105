import "./Profile.css";
function Profile (){
    return(
        <div className="layout">
            <img src="assets/Mint.png" alt="profile" />
            <h1 className="name">Petchpailin Saringkareekul</h1>
            <hr></hr>
        </div>
    )
}
export default Profile;