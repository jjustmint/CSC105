function CardList(){
    return (
        <div style={{ padding: "20px", background: "#fefffe", width:"500px", border:"10px", margin:"20px 0px", fontSize:"25px", color: "#7b7b7b"}}>
            This is Card
        </div>
    );
}
export default CardList;